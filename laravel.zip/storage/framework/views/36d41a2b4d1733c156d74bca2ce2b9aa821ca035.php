<?php $__env->startSection('pageTitle'); ?>
View Activity Details
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footerScripts'); ?>
<script type="text/javascript">
	$( ".confirmDelete" ).click(function() {
  		return confirm( "Are you sure you want to delete this activity?" );
	});

	$( ".confirmEdit" ).click(function() {
  		return confirm( "Are you sure you want to edit this activity?\n\nChanging the date on activity entries may affect your treatment if entered incorrectly." );
	});
</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<h1>View Today's Activity Details</h1>
	
	<div class="row">
		<div class="col-md-12">
		<?php if( count($activities) >= 1 ): ?>
			<table class="table">
				<tr>
					<th>Type</th>
					<th><?php if( 'bp' == $activities[0]->type ): ?>
					BP Reading
					<?php else: ?>
					Water Amount
					<?php endif; ?>
					</th>
					<th>Date</th>
					<th>Action</th>
				</tr>
				<?php $__currentLoopData = $activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td><?php if( 'bp' != $activity->type ): ?>
						Water <?php echo e(ucfirst( $activity->type )); ?>

						<?php else: ?>
						Blood Pressure
						<?php endif; ?>
					</td>
					<td><?php echo e($activity['amount1']); ?>

					<?php if( 'bp' != $activity->type ): ?>
						ml
					<?php else: ?>
					&nbsp;/&nbsp;<?php echo e($activity['amount2']); ?>

					<?php endif; ?>
					</td>
					<td><?php echo e(date('d/M/Y', strtotime( $activity['saved_at'] ))); ?></td>
					<td>
						<a href="delete/<?php echo e($activity['id']); ?>" class="confirmDelete">Delete</a>&nbsp;|&nbsp;<a href="/edit/<?php echo e($activity['id']); ?>" class="confirmEdit">Edit</a>
					</td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<?php else: ?>
				<tr>
					<td colspan="3">There are no activities today.</td>
				</tr>

			</table>
			<?php endif; ?>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>