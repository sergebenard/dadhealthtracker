<?php $__env->startSection('pageTitle'); ?>
View Activity Details
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footerScripts'); ?>
<script type="text/javascript">
	$( ".confirmDelete" ).click(function() {
  		return confirm( "Are you sure you want to delete this activity?" );
	});

	$( ".confirmEdit" ).click(function() {
  		return confirm( "Are you sure you want to edit this activity?\n\nChanging the date on activity entries may affect your treatment if entered incorrectly." );
	});
</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<h1>View Activity Details</h1>
	
	<div class="row">
		<div class="col-md-12">
			<table class="table">
				<tr>
					<th>Type</th>
					<th><?php if( 'bp' == $activity->type ): ?>
					BP Reading
					<?php else: ?>
					Water Amount
					<?php endif; ?>
					</th>
					<th>Date</th>
					<th>Action</th>
				</tr>
				<tr>
					<td><?php if( 'bp' != $activity->type ): ?>
						Water <?php echo e(ucfirst( $activity->type )); ?>

						<?php else: ?>
						Blood Pressure
						<?php endif; ?>
					</td>
					<td><?php echo e($activity['amount1']); ?>

					<?php if( 'bp' != $activity->type ): ?>
						ml
					<?php else: ?>
					&nbsp;/&nbsp;<?php echo e($activity['amount2']); ?>

					<?php endif; ?>
					</td>
					<td><?php echo e(date('d/M/Y', strtotime( $activity['saved_at'] ))); ?></td>
					<td>
						<a href="delete/<?php echo e($activity['id']); ?>" class="confirmDelete">Delete</a>&nbsp;|&nbsp;<a href="/edit/<?php echo e($activity['id']); ?>" class="confirmEdit">Edit</a>
					</td>
				</tr>
			</table>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>